import { OpenProductDetailsDirective } from './open-product-details.directive';

describe('OpenProductDetailsDirective', () => {
  it('should create an instance', () => {
    const directive = new OpenProductDetailsDirective();
    expect(directive).toBeTruthy();
  });
});
